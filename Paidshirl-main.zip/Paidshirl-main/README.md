# fbshare
Share facebook post


## Installation
```shell
pkg install python;pkg install git;pip install rich requests aiohttp;termux-setup-storage
```
type mo lang ng type *'Y'* tapos enter pag huminto.
pag tapos na clone mo na repo 🤣
```shell
git clone https://github.com/christhenoob13/fbshare.git;cd fbshare
```

then run mo na yung code
```shell
python spamshare.py
```
